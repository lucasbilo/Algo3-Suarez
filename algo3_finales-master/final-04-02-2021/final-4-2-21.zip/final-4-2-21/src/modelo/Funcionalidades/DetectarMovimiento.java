package modelo.Funcionalidades;

public interface DetectarMovimiento {

    void notificarMovimiento();
}
