package modelo.Funcionalidades;

public interface Sonar {

    void sonar();
}
