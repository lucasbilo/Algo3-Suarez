package modelo.Dispositivos;

import modelo.CentralUnicaGlobalDeNotificaciones;
import modelo.Usuario;

public abstract class DispositivoInteligente {

    protected Usuario duenio;
    protected CentralUnicaGlobalDeNotificaciones central;
}
