package modelo.Alertas;

public class AlertaEspecial implements Alerta {
}
