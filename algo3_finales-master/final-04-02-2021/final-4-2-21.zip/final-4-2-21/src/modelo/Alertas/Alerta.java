package modelo.Alertas;

public interface Alerta {
}
