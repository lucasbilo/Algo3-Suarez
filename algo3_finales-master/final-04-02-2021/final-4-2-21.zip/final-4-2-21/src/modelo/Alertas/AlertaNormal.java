package modelo.Alertas;

public class AlertaNormal implements Alerta {
}
